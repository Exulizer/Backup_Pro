@echo off
setlocal
cd /d "%~dp0"

REM --- Design Setup ---
color 07
cls

REM --- Header ---
echo.
echo  ==============================================================================
echo                             BACKUP PRO INSTALLER
echo  ==============================================================================
echo.
echo  Willkommen beim Installations-Assistenten.
echo  Bitte warten Sie, waehrend die Umgebung eingerichtet wird...
echo.
echo  ------------------------------------------------------------------------------
echo.

REM --- Helper fuer Progress Bar ---
set "UI_SCRIPT=%~dp0_ui_progress.py"

REM Clean Python Generator
echo import sys > "%UI_SCRIPT%"
echo import os >> "%UI_SCRIPT%"
echo os.system('') >> "%UI_SCRIPT%"
echo def p(k, m): >> "%UI_SCRIPT%"
echo     try: >> "%UI_SCRIPT%"
echo         w = 50 >> "%UI_SCRIPT%"
echo         f = int(w * k / 100) >> "%UI_SCRIPT%"
echo         c_on = '\033[92m' >> "%UI_SCRIPT%"
echo         c_off = '\033[0m' >> "%UI_SCRIPT%"
echo         try: >> "%UI_SCRIPT%"
echo             b_c = '\u2588' * f + '\u2591' * (w - f) >> "%UI_SCRIPT%"
echo             sys.stdout.write(f"\r  [{c_on}{b_c}{c_off}] {k}%%  {m:<40}") >> "%UI_SCRIPT%"
echo         except: >> "%UI_SCRIPT%"
echo             b_c = '#' * f + '.' * (w - f) >> "%UI_SCRIPT%"
echo             sys.stdout.write(f"\r  [{c_on}{b_c}{c_off}] {k}%%  {m:<40}") >> "%UI_SCRIPT%"
echo         sys.stdout.flush() >> "%UI_SCRIPT%"
echo         if k == 100: print() >> "%UI_SCRIPT%"
echo     except: pass >> "%UI_SCRIPT%"
echo if __name__ == "__main__": >> "%UI_SCRIPT%"
echo     try: >> "%UI_SCRIPT%"
echo         p(int(sys.argv[1]), sys.argv[2] if len(sys.argv) ^> 2 else "") >> "%UI_SCRIPT%"
echo     except: pass >> "%UI_SCRIPT%"

REM --- 1. Python Check ---
set "PY_CMD="

if exist ".venv\Scripts\python.exe" (
    set "PY_CMD=.venv\Scripts\python.exe"
    goto :LAUNCH
)

where python >nul 2>&1
if %errorlevel% equ 0 (
    set "PY_CMD=python"
    goto :CREATE_VENV
)

where py >nul 2>&1
if %errorlevel% equ 0 (
    set "PY_CMD=py"
    goto :CREATE_VENV
)

REM Error Handler
color 0C
echo.
echo  [FEHLER] Kein Python gefunden.
echo.
pause
del "%UI_SCRIPT%" >nul 2>&1
exit /b 1

REM --- 2. Venv Setup ---
:CREATE_VENV
"%PY_CMD%" "%UI_SCRIPT%" 0 "Initialisiere..."

"%PY_CMD%" "%UI_SCRIPT%" 20 "Erstelle virtuelle Umgebung..."
"%PY_CMD%" -m venv .venv
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo  [FEHLER] Konnte .venv nicht erstellen.
    del "%UI_SCRIPT%" >nul 2>&1
    pause
    exit /b 1
)

"%PY_CMD%" "%UI_SCRIPT%" 50 "Umgebung erstellt."
set "PY_CMD=.venv\Scripts\python.exe"

REM --- 3. Launch Installer ---
:LAUNCH
"%PY_CMD%" "%UI_SCRIPT%" 80 "Starte Installer GUI..."
"%PY_CMD%" -m pip install --upgrade pip >nul 2>&1
"%PY_CMD%" "%UI_SCRIPT%" 100 "Bereit!"
echo.

REM Start GUI without blocking terminal
start "" "%PY_CMD%" install_backup_pro.py

REM Cleanup
del "%UI_SCRIPT%" >nul 2>&1
exit
