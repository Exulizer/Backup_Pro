import tkinter as tk
from tkinter import ttk, messagebox
import subprocess
import sys
import socket
import os
import threading
import time
import urllib.request
import ssl
import glob
import re
import json
import zipfile
import shutil

# --- Konfiguration & Design (Commander Pro Theme) ---
COLORS = {
    "bg": "#0a0b10",       # Deep Space Black
    "card": "#11141d",     # Dark Panel
    "text": "#c0c8d6",     # Soft Blue-Grey Text
    "accent": "#0084ff",   # Electric Blue (Primary)
    "accent_hover": "#006bbd",
    "border": "#1f2430",   # Subtle Border
    "success": "#10b981",  # Emerald Green
    "error": "#ef4444",    # Red
    "warning": "#f59e0b",  # Amber
    "header": "#e2e8f0",   # Muted White Header
    "console": "#0d0f16"   # Black Console Background
}

# Updated Dependencies for v8
REQUIRED_PACKAGES = [
    "flask", 
    "waitress", 
    "gevent", 
    "requests", 
    "pycryptodomex", 
    "paramiko", 
    "boto3", 
    "dropbox",
    "pywin32",
    "winshell"
]

APP_PORT = 5000
GITHUB_ZIP_URL = "https://github.com/Exulizer/Backup_Pro/archive/refs/heads/main.zip"
APP_NAME = "Backup Pro v8"

class InstallerApp:
    def __init__(self, root):
        self.root = root
        self.app_script = "main.py"
        
        self.root.title(f"{APP_NAME} - Setup Assistant")
        self.root.geometry("800x600")
        self.root.configure(bg=COLORS["bg"])
        
        # Icon setzen
        try:
            icon_path = os.path.join(os.path.dirname(__file__), "resources", "app_icon.ico")
            if not os.path.exists(icon_path):
                 # Try fallback location
                 icon_path = os.path.join(os.path.dirname(__file__), "static", "app_icon.ico")
            if os.path.exists(icon_path):
                self.root.iconbitmap(icon_path)
        except Exception as e:
            print(f"Icon Error: {e}")

        self.setup_styles()
        self.setup_ui()
        self.check_pre_requirements()

    def setup_styles(self):
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure("TFrame", background=COLORS["bg"])
        self.style.configure("Card.TFrame", background=COLORS["card"], relief="flat")
        self.style.configure("TLabel", background=COLORS["bg"], foreground=COLORS["text"], font=("Segoe UI", 10))
        self.style.configure("Header.TLabel", background=COLORS["bg"], foreground=COLORS["header"], font=("Inter", 24, "bold"))
        self.style.configure("Horizontal.TProgressbar", background=COLORS["accent"], troughcolor=COLORS["card"], borderwidth=0, thickness=6)

    def check_pre_requirements(self):
        try:
            import win32com.client
        except ImportError:
            self.log("Initialisiere Setup-Umgebung (pywin32)...", "warn")
            subprocess.call([sys.executable, "-m", "pip", "install", "pywin32", "winshell"])

    def setup_ui(self):
        main_frame = tk.Frame(self.root, bg=COLORS["bg"], padx=40, pady=40)
        main_frame.pack(fill="both", expand=True)

        # Header
        header_frame = tk.Frame(main_frame, bg=COLORS["bg"])
        header_frame.pack(side="top", fill="x", pady=(0, 30))
        
        lbl_logo = tk.Label(header_frame, text="🛡️", bg=COLORS["bg"], fg=COLORS["accent"], font=("Segoe UI", 32))
        lbl_logo.pack(side="left", padx=(0, 15))
        
        title_frame = tk.Frame(header_frame, bg=COLORS["bg"])
        title_frame.pack(side="left")
        
        lbl_title = ttk.Label(title_frame, text="BACKUP PRO", style="Header.TLabel")
        lbl_title.pack(anchor="w")
        
        lbl_subtitle = tk.Label(title_frame, text="V8 MODULAR EDITION INSTALLER", bg=COLORS["bg"], fg=COLORS["accent"], font=("Segoe UI", 9, "bold"), justify="left")
        lbl_subtitle.pack(anchor="w")

        # Content Card
        content_card = tk.Frame(main_frame, bg=COLORS["card"], padx=2, pady=2)
        content_card.pack(side="top", fill="both", expand=True)
        
        inner_card = tk.Frame(content_card, bg=COLORS["card"], padx=20, pady=20)
        inner_card.pack(fill="both", expand=True)

        info_text = (
            "Willkommen zum Setup-Assistenten für Backup Pro v8.\n"
            "Dieses Tool installiert die neueste modulare Version und alle Abhängigkeiten.\n\n"
            "• Download der System-Dateien (Core, GUI, Config)\n"
            "• Einrichtung der Python-Umgebung\n"
            "• Erstellung der Start-Skripte\n"
        )
        lbl_info = tk.Label(inner_card, text=info_text, bg=COLORS["card"], fg=COLORS["text"], justify="left", font=("Segoe UI", 10), anchor="w")
        lbl_info.pack(fill="x", pady=(0, 15))
        
        log_label = tk.Label(inner_card, text="INSTALLATION LOG >_", bg=COLORS["card"], fg=COLORS["text"], font=("Consolas", 8, "bold"))
        log_label.pack(anchor="w", pady=(0, 5))

        self.log_text = tk.Text(inner_card, bg=COLORS["console"], fg=COLORS["text"], font=("Consolas", 9), relief="flat", height=10, bd=10)
        self.log_text.pack(fill="both", expand=True)
        
        self.progress = ttk.Progressbar(inner_card, orient="horizontal", mode="indeterminate", style="Horizontal.TProgressbar")
        self.progress.pack(fill="x", pady=(20, 0))
        
        # Buttons
        btn_frame = tk.Frame(main_frame, bg=COLORS["bg"])
        btn_frame.pack(side="bottom", fill="x", pady=(20, 0))

        self.btn_exit = self.create_button(btn_frame, "BEENDEN", self.root.quit, primary=False)
        self.btn_exit.pack(side="right", padx=(10, 0))
        
        self.btn_download = self.create_button(btn_frame, "DOWNLOAD v8", self.download_latest_version, primary=False)
        self.btn_download.pack(side="right", padx=(10, 0))

        self.btn_install = self.create_button(btn_frame, "INSTALLATION STARTEN", self.start_installation, primary=True)
        self.btn_install.pack(side="right")

    def create_button(self, parent, text, command, primary=False):
        bg_color = COLORS["accent"] if primary else COLORS["card"]
        fg_color = "#ffffff" if primary else COLORS["text"]
        btn = tk.Button(parent, text=text, command=command, bg=bg_color, fg=fg_color, font=("Segoe UI", 10, "bold"), relief="flat", padx=25, pady=10, cursor="hand2", borderwidth=0)
        return btn

    def log(self, message, level="info"):
        self.log_text.configure(state="normal")
        prefix = "• " if level == "info" else ("✓ " if level == "success" else ("✗ " if level == "error" else "! "))
        color = COLORS["text"]
        if level == "success": color = COLORS["success"]
        elif level == "error": color = COLORS["error"]
        elif level == "warn": color = COLORS["warning"]
        
        self.log_text.insert("end", f"{prefix}{message}\n")
        self.log_text.tag_add(level, "end-2l", "end-1c")
        self.log_text.tag_config(level, foreground=color)
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def install_package(self, package):
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
            return True
        except:
            return False

    def patch_application(self):
        self.log("Wende Hotfixes an (Port-Scan, Dependencies)...", "info")
        try:
            # 1. Fix requirements.txt
            if os.path.exists("requirements.txt"):
                with open("requirements.txt", "r") as f: content = f.read()
                content = content.replace("dropbox==11.36.0", "dropbox>=11.36.0")
                # Fix others just in case
                content = content.replace("gevent==25.9.1", "gevent") 
                with open("requirements.txt", "w") as f: f.write(content)

            # 2. Inject Port Scanning into gui/web_server.py
            ws_path = os.path.join("gui", "web_server.py")
            if os.path.exists(ws_path):
                with open(ws_path, "r", encoding="utf-8") as f: code = f.read()
                
                if "def find_available_port" not in code:
                    import_socket = "import socket\n\n"
                    func_code = """def find_available_port(start_port=5000, max_tries=50):
    for port in range(start_port, start_port + max_tries):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('0.0.0.0', port))
                return port
        except OSError:
            continue
    return start_port

"""
                    # Insert before start_server
                    code = code.replace("def start_server", import_socket + func_code + "def start_server")
                    # Update start_server signature if needed, but we keep it as is
                    with open(ws_path, "w", encoding="utf-8") as f: f.write(code)

            # 3. Update main.py to use dynamic port
            main_path = "main.py"
            if os.path.exists(main_path):
                with open(main_path, "r", encoding="utf-8") as f: code = f.read()
                
                if "find_available_port" not in code:
                    # Update import
                    code = code.replace("from gui.web_server import create_app, start_server", "from gui.web_server import create_app, start_server, find_available_port")
                    
                    # Update logic
                    # Find where app is created
                    if "app = create_app" in code:
                        insert_point = 'app = create_app(config_manager, db_manager, backup_engine, scheduler)\n'
                        new_logic = """    
    # Find available port
    port = find_available_port(5000)
"""
                        code = code.replace(insert_point, insert_point + new_logic)
                        
                        # Update browser open
                        code = code.replace('webbrowser.open("http://127.0.0.1:5000")', 'webbrowser.open(f"http://127.0.0.1:{port}")')
                        
                        # Update logger
                        code = code.replace('logger.info("Starting Web Server on port 5000...")', 'logger.info(f"Starting Web Server on port {port}...")')
                        
                        # Update start_server call
                        code = code.replace('start_server(app)', 'start_server(app, port=port)')
                        
                        with open(main_path, "w", encoding="utf-8") as f: f.write(code)
                        
            self.log("Hotfixes angewendet.", "success")
        except Exception as e:
            self.log(f"Fehler beim Patchen: {e}", "warn")

    def download_latest_version(self):
        self.log("Starte Download der v8 Repository...", "info")
        self.btn_download.config(state="disabled")
        self.progress.start(10)
        
        def _download():
            try:
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                
                url = GITHUB_ZIP_URL
                zip_name = "update.zip"
                
                self.root.after(0, lambda: self.log(f"Lade herunter: {url}", "info"))
                
                req = urllib.request.Request(url, headers={'User-Agent': 'BackupPro-Installer'})
                with urllib.request.urlopen(req, context=ctx) as response:
                    with open(zip_name, 'wb') as out_file:
                        shutil.copyfileobj(response, out_file)
                
                self.root.after(0, lambda: self.log("Download fertig. Entpacke...", "info"))
                
                # Extract
                with zipfile.ZipFile(zip_name, 'r') as zip_ref:
                    # Check root folder name (usually Backup_Pro-main)
                    root_dir = zip_ref.namelist()[0].split('/')[0]
                    zip_ref.extractall("temp_update")
                
                # Move files from temp_update/Root to current dir
                source_dir = os.path.join("temp_update", root_dir)
                for item in os.listdir(source_dir):
                    s = os.path.join(source_dir, item)
                    d = os.path.join(os.getcwd(), item)
                    if os.path.exists(d):
                        if os.path.isdir(d):
                            shutil.rmtree(d)
                        else:
                            os.remove(d)
                    shutil.move(s, d)
                
                # Cleanup
                shutil.rmtree("temp_update")
                os.remove(zip_name)
                
                # Apply Hotfixes
                self.patch_application()
                
                self.root.after(0, lambda: self.log("Update erfolgreich installiert!", "success"))
                self.root.after(0, lambda: messagebox.showinfo("Erfolg", "Backup Pro v8 Dateien wurden aktualisiert."))
                
            except Exception as e:
                self.root.after(0, lambda err=e: self.log(f"Fehler beim Update: {err}", "error"))
                self.root.after(0, lambda err=e: messagebox.showerror("Fehler", f"Update fehlgeschlagen: {err}"))
            
            self.root.after(0, lambda: self.btn_download.config(state="normal"))
            self.root.after(0, self.progress.stop)
            
        threading.Thread(target=_download, daemon=True).start()

    def create_launcher(self):
        try:
            content = """import os
import sys
import subprocess
import time
import shutil

def get_python_executable():
    # Check for PyPy (Optimierte Performance)
    pypy = shutil.which("pypy3") or shutil.which("pypy")
    if pypy:
        print(f"PyPy gefunden: {pypy} (Optimierte Performance)")
        return pypy
    return sys.executable

if __name__ == "__main__":
    print("Starte Backup Pro v8...")
    script = "main.py"
    
    # Change to script directory
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    if os.path.exists(script):
        try:
            python_exe = get_python_executable()
            cmd = [python_exe, script] + sys.argv[1:]
            subprocess.run(cmd, check=False)
        except Exception as e:
            print(f"Fehler beim Starten: {e}")
            time.sleep(10)
    else:
        print("FEHLER: main.py nicht gefunden!")
        print("Bitte führen Sie die Installation erneut aus oder prüfen Sie den Ordner.")
        time.sleep(10)
"""
            with open("launcher.py", "w") as f:
                f.write(content)
            
            # BAT
            bat_content = f"""@echo off
title Backup Pro Launcher
echo Starte Backup Pro v8...
cd /d "%~dp0"

if exist ".venv\\Scripts\\python.exe" (
    ".venv\\Scripts\\python.exe" "main.py"
) else (
    echo Warnung: Lokale .venv nicht gefunden. Versuche System-Python...
    python "main.py"
)

if %errorlevel% neq 0 pause
"""
            with open("start_backup_pro.bat", "w") as f:
                f.write(bat_content)
            
            # Copy to startapp.bat as requested by user before
            shutil.copy("start_backup_pro.bat", "startapp.bat")
            return True
        except Exception as e:
            self.log(f"Launcher Fehler: {e}", "error")
            return False

    def create_shortcut(self):
        try:
            import winshell
            from win32com.client import Dispatch
            import pythoncom
            
            try: pythoncom.CoInitialize()
            except: pass
            
            desktop = winshell.desktop()
            path = os.path.join(desktop, f"{APP_NAME}.lnk")
            target = os.path.join(os.getcwd(), "start_backup_pro.bat")
            
            shell = Dispatch('WScript.Shell')
            shortcut = shell.CreateShortCut(path)
            shortcut.TargetPath = target
            shortcut.WorkingDirectory = os.getcwd()
            
            icon_path = os.path.join(os.getcwd(), "resources", "app_icon.ico")
            if os.path.exists(icon_path):
                shortcut.IconLocation = icon_path
            else:
                shortcut.IconLocation = sys.executable
            
            shortcut.save()
            return True
        except:
            return False

    def start_installation(self):
        self.btn_install.config(state="disabled")
        self.progress.start(10)
        threading.Thread(target=self.run_install_process, daemon=True).start()

    def run_install_process(self):
        self.log("Starte System-Setup...", "info")
        time.sleep(1)
        
        # 1. Dependencies
        self.log("Prüfe Abhängigkeiten...", "info")
        all_success = True
        for pkg in REQUIRED_PACKAGES:
            self.log(f"Installiere {pkg}...")
            if self.install_package(pkg):
                self.log(f"{pkg} OK.", "success")
            else:
                self.log(f"Fehler bei {pkg}", "error")
                all_success = False
        
        # 2. Launcher
        self.log("Konfiguriere Boot-Loader...", "info")
        if self.create_launcher():
            self.log("Launcher erstellt.", "success")
        
        # 3. Shortcut
        self.log("Erstelle Verknüpfung...", "info")
        if self.create_shortcut():
            self.log("Desktop Icon erstellt.", "success")
            
        self.progress.stop()
        self.progress.configure(mode="determinate", value=100)
        
        if all_success:
            self.log("Installation erfolgreich!", "success")
            self.root.after(0, lambda: messagebox.showinfo("Fertig", "Backup Pro v8 ist einsatzbereit!"))
        else:
            self.log("Installation mit Fehlern beendet.", "warn")
            
        self.root.after(0, lambda: self.btn_install.config(state="normal", text="Fertig"))

if __name__ == "__main__":
    try:
        root = tk.Tk()
        app = InstallerApp(root)
        root.mainloop()
    except Exception as e:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, str(e), "Fataler Fehler", 0x10)
